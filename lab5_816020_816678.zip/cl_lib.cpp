
#include <fcntl.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include <vector>
#include <stdexcept>

#ifdef __APPLE__
    #include <OpenCL/opencl.h>
#else
    #include <CL/cl.h>
#endif


void cl_error(cl_int code, std::string msg)
{
	if (code != CL_SUCCESS){
		throw std::runtime_error(msg);
	}
}
  


class Cl_function
{
    cl_kernel kernel;

public:

    Cl_function (cl_context context, cl_device_id device_id, std::string name, std::string source_code)
    {
        cl_int err;
        auto fileSize = source_code.size();
        auto source_code_char = source_code.c_str();

        // cl_program Program = clCreateProgramWithSource(context, 1, (const char **) &source_code, &fileSize, &err);
        cl_program Program = clCreateProgramWithSource(context, 1, (const char **) &source_code_char, &fileSize, &err);
        cl_error(err, "Failed to create a program"+name+"with source\n");

        size_t log_size;
        // Get the size of the log
        clGetProgramBuildInfo(Program, device_id, CL_PROGRAM_BUILD_LOG, 0, nullptr, &log_size);

        // Allocate memory for the log
        std::vector<char> log(log_size);

        // Retrieve the log
        clGetProgramBuildInfo(Program, device_id, CL_PROGRAM_BUILD_LOG, log_size, log.data(), nullptr);

        // Print the log
        // std::cerr << "Build log:\n" << log.data() << std::endl;

        const cl_device_id devices[] = { device_id };
        err = clBuildProgram(Program, 1, devices, "", NULL, NULL);
        cl_error(err, "Failed to build program\n");


        kernel = clCreateKernel(Program, name.c_str(), &err);
        // cl_error(err, "Failed?");
    }

    cl_kernel get()
    {
        return kernel;
    }
};


class Cl_runtime
{
    cl_context context;
    cl_command_queue queue;
    cl_device_id device_id;

public:

    ~Cl_runtime()
    {
        clReleaseCommandQueue(queue);
        clReleaseContext(context);
    }

    Cl_runtime()
    {
        int err;                            	// error code returned from api calls
        size_t t_buf = 50;			// size of str_buffer
        char str_buffer[t_buf];		// auxiliary buffer	
        size_t e_buf;				// effective size of str_buffer in use
                
        size_t global_size;                      	// global domain size for our calculation
        size_t local_size;                       	// local domain size for our calculation

        const cl_uint num_platforms_ids = 10;				// max of allocatable platforms
        cl_platform_id platforms_ids[num_platforms_ids];		// array of platforms
        cl_uint n_platforms;						// effective number of platforms in use
        const cl_uint num_devices_ids = 10;				// max of allocatable devices
        cl_device_id devices_ids[num_platforms_ids][num_devices_ids];	// array of devices
        cl_uint n_devices[num_platforms_ids];				// effective number of devices in use for each platform
            
        // 1. Scan the available platforms:
        err = clGetPlatformIDs (num_platforms_ids, platforms_ids, &n_platforms);
        cl_error(err, "Error: Failed to Scan for Platforms IDs");
        //printf("Number of available platforms: %d\n\n", n_platforms);

        for (int i = 0; i < n_platforms; i++ )
        {
            err= clGetPlatformInfo(platforms_ids[i], CL_PLATFORM_NAME, sizeof(str_buffer), str_buffer, NULL);
            cl_error (err, "Error: Failed to get info of the platform\n");
            //printf( "\t[%d]-Platform Name: %s\n", i, str_buffer);

            // Task: Print more information about the platform
            clGetPlatformInfo(platforms_ids[i], CL_PLATFORM_VENDOR, sizeof(str_buffer), str_buffer, NULL);
            //printf("\t\tPlatform Vendor: %s\n", str_buffer);
            
            clGetPlatformInfo(platforms_ids[i], CL_PLATFORM_VERSION, sizeof(str_buffer), str_buffer, NULL);
            //printf("\t\tPlatform Version: %s\n", str_buffer);

            clGetPlatformInfo(platforms_ids[i], CL_PLATFORM_PROFILE, sizeof(str_buffer), str_buffer, NULL);
            //printf("\t\tPlatform Profile: %s\n", str_buffer);

            clGetPlatformInfo(platforms_ids[i], CL_PLATFORM_HOST_TIMER_RESOLUTION, sizeof(e_buf), &e_buf, NULL);
            //printf("\t\tHost Timer Resolution: %zu\n", e_buf);
        }
        //printf("\n");
        // ***Task***: print on the screen the name, host_timer_resolution, vendor, versionm, ...
            
        // 2. Scan for devices in each platform
        for (int i = 0; i < n_platforms; i++ )
        {
            err = clGetDeviceIDs(platforms_ids[i], CL_DEVICE_TYPE_ALL, num_devices_ids, devices_ids[i], &(n_devices[i]));
            cl_error(err, "Error: Failed to Scan for Devices IDs");
            //printf("\t[%d]-Platform. Number of available devices: %d\n", i, n_devices[i]);

            for(int j = 0; j < n_devices[i]; j++)
            {
                err = clGetDeviceInfo(devices_ids[i][j], CL_DEVICE_NAME, sizeof(str_buffer), str_buffer, NULL);
                cl_error(err, "clGetDeviceInfo: Getting device name");
                //printf("\t\t [%d]-Platform [%d]-Device CL_DEVICE_NAME: %s\n", i, j,str_buffer);

                cl_uint max_compute_units_available;
                err = clGetDeviceInfo(devices_ids[i][j], CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(max_compute_units_available), &max_compute_units_available, NULL);
                cl_error(err, "clGetDeviceInfo: Getting device max compute units available");
                //printf("\t\t [%d]-Platform [%d]-Device CL_DEVICE_MAX_COMPUTE_UNITS: %d\n\n", i, j, max_compute_units_available);

                // Print additional device information
                size_t global_mem_size;
                err = clGetDeviceInfo(devices_ids[i][j], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(global_mem_size), &global_mem_size, NULL);
                cl_error(err, "clGetDeviceInfo: Getting device global memory size");
                //printf("\t\t [%d]-Platform [%d]-Device CL_DEVICE_GLOBAL_MEM_SIZE: %zu bytes\n", i, j, global_mem_size);

                cl_ulong local_mem_size;
                err = clGetDeviceInfo(devices_ids[i][j], CL_DEVICE_LOCAL_MEM_SIZE, sizeof(local_mem_size), &local_mem_size, NULL);
                cl_error(err, "clGetDeviceInfo: Getting device local memory size");
                //printf("\t\t [%d]-Platform [%d]-Device CL_DEVICE_LOCAL_MEM_SIZE: %lu bytes\n", i, j, local_mem_size);

                cl_ulong max_mem_alloc_size;
                err = clGetDeviceInfo(devices_ids[i][j], CL_DEVICE_MAX_MEM_ALLOC_SIZE, sizeof(max_mem_alloc_size), &max_mem_alloc_size, NULL);
                cl_error(err, "clGetDeviceInfo: Getting device max memory allocation size");
                //printf("\t\t [%d]-Platform [%d]-Device CL_DEVICE_MAX_MEM_ALLOC_SIZE: %lu bytes\n", i, j, max_mem_alloc_size);

                size_t max_work_group_size;
                err = clGetDeviceInfo(devices_ids[i][j], CL_DEVICE_MAX_WORK_GROUP_SIZE, sizeof(max_work_group_size), &max_work_group_size, NULL);
                cl_error(err, "clGetDeviceInfo: Getting device max work group size");
                //printf("\t\t [%d]-Platform [%d]-Device CL_DEVICE_MAX_WORK_GROUP_SIZE: %zu\n\n", i, j, max_work_group_size);
            }
        }	
        // ***Task***: print on the screen the cache size, global mem size, local memsize, max work group size, profiling timer resolution and ... of each device


        // 3. Create a context, with a device
        cl_context_properties properties[] = { CL_CONTEXT_PLATFORM, (cl_context_properties)platforms_ids[0], 0}; // Using the first platform
        context = clCreateContext(properties, n_devices[0], devices_ids[0], NULL, NULL, &err);
        cl_error(err, "Failed to create a compute context\n");

        // 4. Create a command queue
        cl_command_queue_properties proprt[] = { CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0 };
        queue = clCreateCommandQueueWithProperties(context, devices_ids[0][0], proprt, &err); // Using the first device
        cl_error(err, "Failed to create a command queue\n");
        device_id = devices_ids[0][0];
    }

    Cl_function createFunction(std::string name, std::string sourceCode) const
    {
        return Cl_function(context, device_id, name, sourceCode);
    }

    std::vector<float> runBufferFunction(Cl_function &f, std::vector<float> &in)
    {
        cl_int err;
        size_t count = in.size();
        std::vector<float> out(count);

        cl_mem input = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");

        err = clSetKernelArg(f.get(), 0, sizeof(cl_mem), &input);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 1, sizeof(cl_mem), &output);
        cl_error(err, "Failed to set kernel arg 1\n");
        err = clSetKernelArg(f.get(), 2, sizeof(unsigned int), &count);
        cl_error(err, "Failed to set kernel arg 2\n");

        err = clEnqueueWriteBuffer(queue, input, CL_TRUE, 0, sizeof(float) * count, in.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");
        err = clEnqueueNDRangeKernel(queue, f.get(), 1, NULL, &count, NULL, 0, NULL, NULL);
        cl_error(err, "Failed to enqueue kernel\n");
        err = clEnqueueReadBuffer(queue, output, CL_TRUE, 0, sizeof(float) * count, out.data(), 0, NULL, NULL);
        cl_error(err, "Failed to read buffer\n");

        // Wait for the command queue to finish
        clFinish(queue);
        clReleaseMemObject(input);
        clReleaseMemObject(output);

        return out;
    }


    std::string s_convolution() const
    {
        std::string convolution_code = 
        "__kernel void convolution("
            "__global float *matrix,"
            "__global float *ka,"
            "__global float *out,"
            "const unsigned int rows,"
            "const unsigned int cols,"
            "const unsigned int kernel_rows,"
            "const unsigned int kernel_cols)"
        "{"

            "int i = get_global_id(0);"
            "int j = get_global_id(1);"

            "if(i < rows && j < cols)"
            "{"
            "      float sum = 0;"
            "      for (int k = 0; k < kernel_rows; k++)"
            "      {"
            "          for (int l = 0; l < kernel_cols; l++)"
            "          {"
            "               if (i+k >= 0 && i+k < rows && j+l >= 0 && j+l < cols) {"
            "                    sum += matrix[(i+k)*cols + j+l] * ka[k*kernel_cols + l];"
            "                }"
                            
            "          }"
            "       }"
               
            "       out[i*cols + j] = sum;"
            "}"
        "}";    

        return convolution_code;
    }


    std::vector<std::vector<float>> convolution(
            std::vector<std::vector<float>> &matrix, 
            std::vector<std::vector<float>> &kernel)
    {
        std::vector<float> flattenMatrix(matrix.size()*matrix[0].size());
        std::vector<float> flattenKernel(kernel.size()*kernel[0].size());

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                flattenMatrix[i*matrix[0].size() + j] = matrix[i][j];
            }
        }

        for (size_t i = 0; i < kernel.size(); i++){
            for (size_t j = 0; j < kernel[0].size(); j++){
                flattenKernel[i*kernel[0].size() + j] = kernel[i][j];
            }
        }

        cl_int err;

        size_t count = matrix.size()*matrix[0].size();                 
        Cl_function f = createFunction("convolution", s_convolution());

        auto flatten_result = runConvolutionFunction(f, flattenMatrix, flattenKernel, matrix[0].size(), matrix[1].size(), kernel[0].size(), kernel[1].size());
    
        std::vector<std::vector<float>> result(matrix.size(), std::vector<float>(matrix[0].size()));

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                result[i][j] = flatten_result[i*matrix[0].size() + j];
            }
        }

        return result;
    }

    std::vector<float> runConvolutionFunction(Cl_function &f, std::vector<float> &matrix,
            std::vector<float> &kernel,
             size_t rows, size_t cols, size_t kernel_rows, size_t kernel_cols)
    {
        cl_int err;
        size_t count = rows * cols;
        size_t kernel_count = kernel_rows * kernel_cols;
        std::vector<float> out(count);

        cl_mem input = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem kernel_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * kernel_count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");

        // Set kernel arguments
        err = clSetKernelArg(f.get(), 0, sizeof(cl_mem), &input);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 1, sizeof(cl_mem), &kernel_buffer);
        cl_error(err, "Failed to set kernel arg 1\n");
        err = clSetKernelArg(f.get(), 2, sizeof(cl_mem), &output);
        cl_error(err, "Failed to set kernel arg 2\n");
        err = clSetKernelArg(f.get(), 3, sizeof(unsigned int), &rows);
        cl_error(err, "Failed to set kernel arg 3\n");
        err = clSetKernelArg(f.get(), 4, sizeof(unsigned int), &cols);
        cl_error(err, "Failed to set kernel arg 4\n");
        err = clSetKernelArg(f.get(), 5, sizeof(unsigned int), &kernel_rows);
        cl_error(err, "Failed to set kernel arg 5\n");
        err = clSetKernelArg(f.get(), 6, sizeof(unsigned int), &kernel_cols);
        cl_error(err, "Failed to set kernel arg 6\n");

        // Write input and kernel buffer to device memory
        err = clEnqueueWriteBuffer(queue, input, CL_TRUE, 0, sizeof(float) * count, matrix.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");

        err = clEnqueueWriteBuffer(queue, kernel_buffer, CL_TRUE, 0, sizeof(float) * kernel_count, kernel.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");

        // Enqueue kernel execution
        size_t global_work_size[2] = {rows, cols};
        err = clEnqueueNDRangeKernel(queue, f.get(), 2, NULL, global_work_size, NULL, 0, NULL, NULL);
        cl_error(err, "Failed to enqueue kernel\n");

        // Read result buffer
        err = clEnqueueReadBuffer(queue, output, CL_TRUE, 0, sizeof(float) * count, out.data(), 0, NULL, NULL);
        cl_error(err, "Failed to read buffer\n");

        // Wait for the command queue to finish
        clFinish(queue);

        // Clean up memory
        clReleaseMemObject(input);
        clReleaseMemObject(output);
        clReleaseMemObject(kernel_buffer);

        return out;
    }

    std::vector<std::vector<float>> pow2(std::vector<std::vector<float>> &matrix)
    {
        std::vector<float> flattenMatrix(matrix.size()*matrix[0].size());

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                flattenMatrix[i*matrix[0].size() + j] = matrix[i][j];
            }
        }

        cl_int err;


        std::string s = "__kernel void pow2("
            "__global float *in,"
            "__global float *out,"
            "const unsigned int count){"

            "int i = get_global_id(0);"

            "if(i < count){"
            "  out[i] = in[i] * in[i];"
            "}"
        "}";

        Cl_function f = createFunction("pow2", s);

        size_t count = matrix.size()*matrix[0].size();

        auto flatten_result = runPow2(f, flattenMatrix, matrix.size(), matrix[0].size(), matrix[0].size()/2, matrix[1].size()/2);
    
        std::vector<std::vector<float>> result(matrix.size(), std::vector<float>(matrix[0].size()));

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                result[i][j] = flatten_result[i*matrix[0].size() + j];
            }
        }

        return result;
    }

    std::vector<float> runPow2(Cl_function &f, std::vector<float> &in, 
            size_t rows, size_t cols,
            size_t thX, size_t thY)
    {
        cl_int err;
        size_t count = rows*cols;
        std::vector<float> out(count);

        cl_mem input = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");

        err = clSetKernelArg(f.get(), 0, sizeof(cl_mem), &input);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 1, sizeof(cl_mem), &output);
        cl_error(err, "Failed to set kernel arg 1\n");
        err = clSetKernelArg(f.get(), 2, sizeof(unsigned int), &count);
        cl_error(err, "Failed to set kernel arg 2\n");

        err = clEnqueueWriteBuffer(queue, input, CL_TRUE, 0, sizeof(float) * count, in.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");
        
        // Launch 2d kernel
        size_t global_work_size[2] = {thX, thY};
        err = clEnqueueNDRangeKernel(queue, f.get(), 2, NULL, global_work_size, NULL, 0, NULL, NULL);
        cl_error(err, "Failed to enqueue kernel\n");

        err = clEnqueueReadBuffer(queue, output, CL_TRUE, 0, sizeof(float) * count, out.data(), 0, NULL, NULL);
        cl_error(err, "Failed to read buffer\n");

        // Wait for the command queue to finish
        clFinish(queue);
        clReleaseMemObject(input);
        clReleaseMemObject(output);

        return out;
    }

std::vector<std::vector<float>> sumSqrt(std::vector<std::vector<float>> &matrix, std::vector<std::vector<float>> &matrix2)
    {
        std::vector<float> flattenMatrix(matrix.size()*matrix[0].size());
        std::vector<float> flattenMatrix2(matrix2.size()*matrix2[0].size());

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                flattenMatrix[i*matrix[0].size() + j] = matrix[i][j];
            }
        }

        for (size_t i = 0; i < matrix2.size(); i++){
            for (size_t j = 0; j < matrix2[0].size(); j++){
                flattenMatrix2[i*matrix2[0].size() + j] = matrix2[i][j];
            }
        }

        cl_int err;


        std::string s = "__kernel void sumSqrt("
            "__global float *in,"
            "__global float *in2,"
            "__global float *out,"
            "const unsigned int count){"

            "int i = get_global_id(0);"

            "if(i < count){"
            "  out[i] = sqrt(in[i] + in2[i]);"
            "}"
        "}";

        Cl_function f = createFunction("sumSqrt", s);

        size_t count = matrix.size()*matrix[0].size();

        auto flatten_result = runSumSqrt(f, flattenMatrix, flattenMatrix2, matrix.size(), matrix[0].size(), matrix[0].size()/2, matrix[1].size()/2);
    
        std::vector<std::vector<float>> result(matrix.size(), std::vector<float>(matrix[0].size()));

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                result[i][j] = flatten_result[i*matrix[0].size() + j];
            }
        }

        return result;
    }

    std::vector<float> runSumSqrt(Cl_function &f, std::vector<float> &in, std::vector<float> &in2, 
            size_t rows, size_t cols,
            size_t thX, size_t thY)
    {
        cl_int err;
        size_t count = rows*cols;
        std::vector<float> out(count);

        cl_mem input = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem input2 = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");

        err = clSetKernelArg(f.get(), 0, sizeof(cl_mem), &input);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 1, sizeof(cl_mem), &input2);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 2, sizeof(cl_mem), &output);
        cl_error(err, "Failed to set kernel arg 1\n");
        err = clSetKernelArg(f.get(), 3, sizeof(unsigned int), &count);
        cl_error(err, "Failed to set kernel arg 2\n");

        err = clEnqueueWriteBuffer(queue, input, CL_TRUE, 0, sizeof(float) * count, in.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");

        err = clEnqueueWriteBuffer(queue, input2, CL_TRUE, 0, sizeof(float) * count, in2.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");
        
        // Launch 2d kernel
        size_t global_work_size[2] = {thX, thY};
        err = clEnqueueNDRangeKernel(queue, f.get(), 2, NULL, global_work_size, NULL, 0, NULL, NULL);
        cl_error(err, "Failed to enqueue kernel\n");

        err = clEnqueueReadBuffer(queue, output, CL_TRUE, 0, sizeof(float) * count, out.data(), 0, NULL, NULL);
        cl_error(err, "Failed to read buffer\n");

        // Wait for the command queue to finish
        clFinish(queue);
        clReleaseMemObject(input);
        clReleaseMemObject(output);

        return out;
    }

    std::vector<std::vector<float>> gradientMagnitudes(std::vector<std::vector<float>> &matrix, std::vector<std::vector<float>> &matrix2)
    {
        std::vector<float> flattenMatrix(matrix.size()*matrix[0].size());
        std::vector<float> flattenMatrix2(matrix2.size()*matrix2[0].size());

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                flattenMatrix[i*matrix[0].size() + j] = matrix[i][j];
            }
        }

        for (size_t i = 0; i < matrix2.size(); i++){
            for (size_t j = 0; j < matrix2[0].size(); j++){
                flattenMatrix2[i*matrix2[0].size() + j] = matrix2[i][j];
            }
        }

        cl_int err;


        std::string s = "__kernel void gradientMagnitudes("
            "__global float *in,"
            "__global float *in2,"
            "__global float *out,"
            "const unsigned int count){"

            "int i = get_global_id(0);"

            "if(i < count){"
            "  out[i] = sqrt((in[i]*in[i]) + (in2[i]*in2[i]));"
            "}"
        "}";

        Cl_function f = createFunction("gradientMagnitudes", s);

        size_t count = matrix.size()*matrix[0].size();

        auto flatten_result = runGradientMagnitudes(f, flattenMatrix, flattenMatrix2, matrix.size(), matrix[0].size(), matrix[0].size()/2, matrix[1].size()/2);
    
        std::vector<std::vector<float>> result(matrix.size(), std::vector<float>(matrix[0].size()));

        for (size_t i = 0; i < matrix.size(); i++){
            for (size_t j = 0; j < matrix[0].size(); j++){
                result[i][j] = flatten_result[i*matrix[0].size() + j];
            }
        }

        return result;
    }

    std::vector<float> runGradientMagnitudes(Cl_function &f, std::vector<float> &in, std::vector<float> &in2, 
            size_t rows, size_t cols,
            size_t thX, size_t thY)
    {
        cl_int err;
        size_t count = rows*cols;
        std::vector<float> out(count);

        cl_mem input = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem input2 = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");

        err = clSetKernelArg(f.get(), 0, sizeof(cl_mem), &input);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 1, sizeof(cl_mem), &input2);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 2, sizeof(cl_mem), &output);
        cl_error(err, "Failed to set kernel arg 1\n");
        err = clSetKernelArg(f.get(), 3, sizeof(unsigned int), &count);
        cl_error(err, "Failed to set kernel arg 2\n");

        err = clEnqueueWriteBuffer(queue, input, CL_TRUE, 0, sizeof(float) * count, in.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");

        err = clEnqueueWriteBuffer(queue, input2, CL_TRUE, 0, sizeof(float) * count, in2.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");
        
        // Launch 2d kernel
        size_t global_work_size[2] = {thX, thY};
        err = clEnqueueNDRangeKernel(queue, f.get(), 2, NULL, global_work_size, NULL, 0, NULL, NULL);
        cl_error(err, "Failed to enqueue kernel\n");

        err = clEnqueueReadBuffer(queue, output, CL_TRUE, 0, sizeof(float) * count, out.data(), 0, NULL, NULL);
        cl_error(err, "Failed to read buffer\n");

        // Wait for the command queue to finish
        clFinish(queue);
        clReleaseMemObject(input);
        clReleaseMemObject(output);

        return out;
    }


    std::vector<float> runMatrixFunction(Cl_function &f, std::vector<float> &in, 
            size_t rows, size_t cols,
            size_t thX, size_t thY)
    {
        cl_int err;
        size_t count = rows*cols;
        std::vector<float> out(count);

        cl_mem input = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");
        cl_mem output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(float) * count, NULL, &err);
        cl_error(err, "Failed to create buffer\n");

        err = clSetKernelArg(f.get(), 0, sizeof(cl_mem), &input);
        cl_error(err, "Failed to set kernel arg 0\n");
        err = clSetKernelArg(f.get(), 1, sizeof(cl_mem), &output);
        cl_error(err, "Failed to set kernel arg 1\n");
        err = clSetKernelArg(f.get(), 2, sizeof(unsigned int), &rows);
        cl_error(err, "Failed to set kernel arg 2\n");
        err = clSetKernelArg(f.get(), 3, sizeof(unsigned int), &cols);
        cl_error(err, "Failed to set kernel arg 3\n");

        err = clEnqueueWriteBuffer(queue, input, CL_TRUE, 0, sizeof(float) * count, in.data(), 0, NULL, NULL);
        cl_error(err, "Failed to write buffer\n");
        
        // Launch 2d kernel
        size_t global_work_size[2] = {thX, thY};
        err = clEnqueueNDRangeKernel(queue, f.get(), 2, NULL, global_work_size, NULL, 0, NULL, NULL);
        cl_error(err, "Failed to enqueue kernel\n");

        err = clEnqueueReadBuffer(queue, output, CL_TRUE, 0, sizeof(float) * count, out.data(), 0, NULL, NULL);
        cl_error(err, "Failed to read buffer\n");

        // Wait for the command queue to finish
        clFinish(queue);
        clReleaseMemObject(input);
        clReleaseMemObject(output);

        return out;
    }
};


